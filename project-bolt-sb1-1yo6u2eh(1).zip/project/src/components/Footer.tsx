import React from 'react';
import { Github, Linkedin, Twitter, Mail } from 'lucide-react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-6 md:mb-0">
            <a href="#home" className="text-2xl font-bold text-blue-400">
              LuminarySite
            </a>
            <p className="mt-2 text-gray-400 max-w-md">
              Building beautiful, functional websites that help businesses grow and succeed online.
            </p>
          </div>
          
          <div className="flex flex-col items-center md:items-end">
            <div className="flex space-x-4 mb-4">
              <a 
                href="https://github.com/LuminarySite" 
                className="text-gray-400 hover:text-white transition-colors"
                aria-label="GitHub profile"
              >
                <Github size={24} />
              </a>
              <a 
                href="www.linkedin.com/in/luminary-site-847257368" 
                className="text-gray-400 hover:text-white transition-colors"
                aria-label="LinkedIn profile"
              >
                <Linkedin size={24} />
              </a>
              <a 
                href="https://x.com/LuminarySi20973" 
                className="text-gray-400 hover:text-white transition-colors"
                aria-label="Twitter profile"
              >
                <Twitter size={24} />
              </a>
              <a 
                href="mailto:luminarysite294@gmail.com" 
                className="text-gray-400 hover:text-white transition-colors"
                aria-label="Email contact"
              >
                <Mail size={24} />
              </a>
            </div>
            <p className="text-gray-500 text-sm">
              &copy; {currentYear} DevPortfolio. All rights reserved.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;