import React, { useState } from 'react';
import { ExternalLink, Github } from 'lucide-react';

interface Project {
  id: number;
  title: string;
  description: string;
  image: string;
  tags: string[];
  liveUrl?: string;
  repoUrl?: string;
  category: 'web' | 'wordpress' | 'all';
}

const Projects: React.FC = () => {
  const [filter, setFilter] = useState<'all' | 'web' | 'wordpress'>('all');
  
  const projects: Project[] = [
    {
      id: 1,
      title: "Modern Real Estate Platform",
      description: "A sophisticated real estate platform with property listings, advanced search, and virtual tours.",
      image: "https://images.pexels.com/photos/323780/pexels-photo-323780.jpeg",
      tags: ["React", "Node.js", "MongoDB", "Google Maps API"],
      liveUrl: "#",
      repoUrl: "#",
      category: "web"
    },
    {
      id: 2,
      title: "Luxury Hotel WordPress Site",
      description: "Custom WordPress theme for a luxury hotel chain featuring room booking and amenities showcase.",
      image: "https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg",
      tags: ["WordPress", "PHP", "Custom Fields", "Booking System"],
      liveUrl: "#",
      category: "wordpress"
    },
    {
      id: 3,
      title: "Fitness Training Platform",
      description: "Interactive fitness platform with workout tracking, nutrition plans, and progress monitoring.",
      image: "https://images.pexels.com/photos/841130/pexels-photo-841130.jpeg",
      tags: ["React", "TypeScript", "Firebase", "Stripe"],
      liveUrl: "#",
      repoUrl: "#",
      category: "web"
    },
    {
      id: 4,
      title: "Creative Agency Portfolio",
      description: "Dynamic WordPress site for a creative agency with case studies and team portfolios.",
      image: "https://images.pexels.com/photos/3182812/pexels-photo-3182812.jpeg",
      tags: ["WordPress", "ACF Pro", "GSAP", "Custom Theme"],
      liveUrl: "#",
      category: "wordpress"
    },
    {
      id: 5,
      title: "E-learning Dashboard",
      description: "Comprehensive learning management system with course tracking and analytics.",
      image: "https://images.pexels.com/photos/5905709/pexels-photo-5905709.jpeg",
      tags: ["React", "Redux", "Node.js", "MongoDB"],
      liveUrl: "#",
      repoUrl: "#",
      category: "web"
    },
    {
      id: 6,
      title: "Food Blog Theme",
      description: "Feature-rich WordPress theme for food bloggers with recipe management and cooking tips.",
      image: "https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg",
      tags: ["WordPress", "PHP", "Recipe Plugin", "Schema Markup"],
      liveUrl: "#",
      category: "wordpress"
    },
    {
      id: 7,
      title: "Medical Clinic Platform",
      description: "Healthcare platform featuring appointment scheduling and patient management.",
      image: "https://images.pexels.com/photos/247786/pexels-photo-247786.jpeg",
      tags: ["React", "Node.js", "PostgreSQL", "WebRTC"],
      liveUrl: "#",
      repoUrl: "#",
      category: "web"
    },
    {
      id: 8,
      title: "Magazine WordPress Site",
      description: "Modern WordPress theme for digital magazines with multimedia content support.",
      image: "https://images.pexels.com/photos/518543/pexels-photo-518543.jpeg",
      tags: ["WordPress", "PHP", "REST API", "Gutenberg"],
      liveUrl: "#",
      category: "wordpress"
    }
  ];

  const filteredProjects = filter === 'all' 
    ? projects 
    : projects.filter(project => project.category === filter);

  return (
    <section id="projects" className="py-20 bg-white dark:bg-gray-800">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <span className="inline-block px-3 py-1 bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-300 rounded-full text-sm font-medium mb-4">
            My Projects
          </span>
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Featured Work
          </h2>
          <p className="text-lg text-gray-600 dark:text-gray-400 mb-8">
            Explore my portfolio of custom websites and applications, showcasing expertise in both web development and WordPress solutions.
          </p>
          
          <div className="flex justify-center space-x-4 mb-8">
            {['all', 'web', 'wordpress'].map((category) => (
              <button
                key={category}
                onClick={() => setFilter(category as any)}
                className={`px-4 py-2 rounded-lg transition-colors ${
                  filter === category
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                }`}
              >
                {category.charAt(0).toUpperCase() + category.slice(1)}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project) => (
            <div 
              key={project.id}
              className="bg-gray-50 dark:bg-gray-700 rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1"
            >
              <div className="relative h-56 overflow-hidden">
                <img 
                  src={project.image} 
                  alt={project.title} 
                  className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end justify-start p-4">
                  <div className="flex space-x-3">
                    {project.liveUrl && (
                      <a 
                        href={project.liveUrl} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="p-2 bg-white rounded-full text-gray-900 hover:bg-blue-600 hover:text-white transition-colors"
                        aria-label="View live site"
                      >
                        <ExternalLink size={20} />
                      </a>
                    )}
                    {project.repoUrl && (
                      <a 
                        href={project.repoUrl} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="p-2 bg-white rounded-full text-gray-900 hover:bg-blue-600 hover:text-white transition-colors"
                        aria-label="View source code"
                      >
                        <Github size={20} />
                      </a>
                    )}
                  </div>
                </div>
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                  {project.title}
                </h3>
                <p className="text-gray-600 dark:text-gray-400 mb-4">
                  {project.description}
                </p>
                <div className="flex flex-wrap gap-2">
                  {project.tags.map((tag, index) => (
                    <span 
                      key={index}
                      className="px-2 py-1 text-xs font-medium bg-gray-200 dark:bg-gray-600 text-gray-700 dark:text-gray-300 rounded"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;