import React from 'react';
import { Code, Globe, Server, Database } from 'lucide-react';

const About: React.FC = () => {
  return (
    <section id="about" className="py-20 bg-white dark:bg-gray-800">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <span className="inline-block px-3 py-1 bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-300 rounded-full text-sm font-medium mb-4">
            About Me
          </span>
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white mb-4">
            I build web experiences that people love
          </h2>
          <p className="text-lg text-gray-600 dark:text-gray-400">
            With over 5 years of experience in web development, I've helped businesses of all sizes establish their online presence with beautiful, functional websites.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {[
            {
              icon: <Code size={40} className="text-blue-600 dark:text-blue-400 mb-4" />,
              title: 'Frontend Development',
              description: 'I build responsive websites using modern HTML, CSS, and JavaScript frameworks.'
            },
            {
              icon: <Server size={40} className="text-purple-600 dark:text-purple-400 mb-4" />,
              title: 'Backend Development',
              description: 'I create robust server-side applications with Node.js and modern frameworks.'
            },
            {
              icon: <Globe size={40} className="text-teal-600 dark:text-teal-400 mb-4" />,
              title: 'WordPress',
              description: 'I develop custom WordPress themes and plugins tailored to client needs.'
            },
            {
              icon: <Database size={40} className="text-red-600 dark:text-red-400 mb-4" />,
              title: 'Database Design',
              description: 'I structure databases for optimal performance and scalability.'
            }
          ].map((item, index) => (
            <div 
              key={index} 
              className="bg-gray-50 dark:bg-gray-700 p-6 rounded-lg hover:shadow-lg transition-shadow"
            >
              {item.icon}
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                {item.title}
              </h3>
              <p className="text-gray-600 dark:text-gray-400">
                {item.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default About;